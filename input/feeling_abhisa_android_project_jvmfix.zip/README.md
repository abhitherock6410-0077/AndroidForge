# FEELING ABHISA — Android project scaffold

This is an Android Studio project scaffold (not a compiled APK). It embeds the heartbroken-yet-in-love web prototype and adds a native Android location permission request through Google Play services location APIs. It fixes the location prompt path for an installed app: tap Refresh, accept the Android location permission, and the app should pass coordinates to the weather fetch.

## Build in Android Studio
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder as a project.
3. Let Gradle sync and download dependencies.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK path after a successful build.

## Important limitations
- This environment does not have Android SDK/Gradle installed, so it cannot compile or sign an APK here.
- The songs saved in Chrome/browser storage do not automatically transfer into the installed app's WebView storage. After installing, select the songs again using Add songs from phone. The app's own library stores the chosen audio in its own browser storage.
- This scaffold fixes location permission handling, but does not yet provide a native background media service/lock-screen controls. WebView timers and playback may pause in background. Reliable lock-screen playback needs a native media playback service.
- It fetches weather from Open-Meteo based on device coordinates; it does not read private data from the Vivo Weather app. Apps cannot access another app's private weather data unless that app exposes an integration.
