package com.feelingabhisa.app

import android.app.*
import android.content.*
import android.location.Location
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class WeatherMusicService : Service() {
    private var player: MediaPlayer? = null
    private val prefs by lazy { getSharedPreferences("feeling_abhisa_native", MODE_PRIVATE) }
    private val handler by lazy { android.os.Handler(mainLooper) }
    private var lastCategory = ""
    private var busy = false
    private val poll = object : Runnable { override fun run() { checkWeather(); handler.postDelayed(this, 15 * 60 * 1000L) } }

    override fun onCreate() { super.onCreate(); createChannel(); startForeground(42, notification("Automatic weather music is active")); handler.post(poll) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { if (intent?.action == "PLAY") playByCategory(intent.getStringExtra("category") ?: "default"); return START_STICKY }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { handler.removeCallbacks(poll); player?.release(); player = null; super.onDestroy() }

    private fun createChannel() { if (Build.VERSION.SDK_INT >= 26) { val nm = getSystemService(NotificationManager::class.java); nm.createNotificationChannel(NotificationChannel("abhisa_weather", "FEELING ABHISA", NotificationManager.IMPORTANCE_LOW)) } }
    private fun notification(text: String): Notification { val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "abhisa_weather") else Notification.Builder(this); return b.setContentTitle("FEELING ABHISA").setContentText(text).setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build() }
    private fun updateNotification(text: String) { (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(42, notification(text)) }

    private fun songs(): JSONArray = try { JSONArray(prefs.getString("songs", "[]")) } catch (_: Exception) { JSONArray() }
    private fun checkWeather() {
        if (busy) return
        busy = true
        thread {
            try {
                val lm = getSystemService(LOCATION_SERVICE) as LocationManager
                val loc: Location? = try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (_: SecurityException) { null }
                if (loc == null) { updateNotification("Waiting for location permission / location fix"); return@thread }
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}&current=weather_code&timezone=auto")
                val c = (url.openConnection() as HttpURLConnection).apply { connectTimeout = 10000; readTimeout = 10000 }
                val json = JSONObject(c.inputStream.bufferedReader().use { it.readText() }); c.disconnect()
                val code = json.getJSONObject("current").getInt("weather_code")
                val category = when (code) { 0,1 -> "sunny"; 2,3 -> "cloudy"; 45,48 -> "fog"; 51,53,55,56,57,61,63,65,66,67,80,81,82 -> "rain"; 95,96,99 -> "storm"; 71,73,75,77,85,86 -> "snow"; else -> "cloudy" }
                if (lastCategory.isEmpty()) lastCategory = prefs.getString("lastCategory", "") ?: ""
                if (category != lastCategory || player == null) { val old = lastCategory; lastCategory = category; prefs.edit().putString("lastCategory", category).apply(); if (old.isNotEmpty() || player == null) playByCategory(category); updateNotification("Weather: $category · automatic mode active") }
            } catch (_: Exception) { updateNotification("Weather check will retry automatically") } finally { busy = false }
        }
    }

    private fun playByCategory(category: String) {
        val list = songs(); if (list.length() == 0) { updateNotification("Add songs in the app to start automatic music"); return }
        val matches = mutableListOf<JSONObject>(); val defaults = mutableListOf<JSONObject>()
        for (i in 0 until list.length()) { val s = list.optJSONObject(i) ?: continue; if (s.optString("cat") == category) matches.add(s); if (s.optString("cat") == "default") defaults.add(s) }
        val chosen = (if (matches.isNotEmpty()) matches else defaults).randomOrNull() ?: run { updateNotification("No song mapped for $category"); return }
        val file = File(chosen.optString("path")); if (!file.exists()) { updateNotification("A saved song is missing; open the app to re-add it"); return }
        handler.post {
            try { player?.release(); player = MediaPlayer().apply { setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()); setDataSource(file.absolutePath); setOnCompletionListener { playByCategory(prefs.getString("lastCategory", "default") ?: "default") }; setOnErrorListener { _,_,_ -> true }; prepare(); start() }; updateNotification("Playing for $category weather") }
            catch (_: Exception) { updateNotification("Could not play saved song") }
        }
    }

    companion object {
        fun start(context: Context) { val i = Intent(context, WeatherMusicService::class.java); if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i) }
        fun syncSong(context: Context, name: String, category: String, base64: String) {
            val dir = File(context.filesDir, "abhisa_songs").apply { mkdirs() }
            val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").take(90).ifBlank { "song" }
            val file = File(dir, "${System.currentTimeMillis()}_$safe")
            file.writeBytes(Base64.decode(base64, Base64.DEFAULT))
            val p = context.getSharedPreferences("feeling_abhisa_native", Context.MODE_PRIVATE)
            val arr = try { JSONArray(p.getString("songs", "[]")) } catch (_: Exception) { JSONArray() }
            arr.put(JSONObject().put("name", name).put("cat", category).put("path", file.absolutePath))
            p.edit().putString("songs", arr.toString()).apply()
            start(context)
        }
        fun updateCategory(context: Context, name: String, category: String) {
            val p = context.getSharedPreferences("feeling_abhisa_native", Context.MODE_PRIVATE); val old = try { JSONArray(p.getString("songs", "[]")) } catch (_: Exception) { JSONArray() }; val arr = JSONArray()
            for (i in 0 until old.length()) { val s = old.optJSONObject(i) ?: continue; if (s.optString("name") == name) s.put("cat", category); arr.put(s) }
            p.edit().putString("songs", arr.toString()).apply()
        }
        fun clearSongs(context: Context) { context.getSharedPreferences("feeling_abhisa_native", Context.MODE_PRIVATE).edit().putString("songs", "[]").apply(); File(context.filesDir, "abhisa_songs").deleteRecursively() }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) { if (intent?.action == Intent.ACTION_BOOT_COMPLETED) try { WeatherMusicService.start(context) } catch (_: Exception) {} }
}
