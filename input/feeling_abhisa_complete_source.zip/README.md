# FEELING ABHISA — native automatic weather music (v1.0.0)

This Android project includes a native foreground service for weather polling and audio playback, persistent copies of imported songs, and a boot receiver. The WebView UI remains the user-facing library and weather-mapping panel.

## Build on AndroidForge
1. Upload this ZIP into the `input/` directory of the existing AndroidForge repository.
2. Run the existing workflow with `zip_source=input-directory` and `zip_path=input/feeling_abhisa_complete_source.zip`.
3. Download the generated APK from the workflow/release and install it on the Vivo phone.

## First-run setup
- Open the app and allow location permission. Internet access is required for Open-Meteo weather checks.
- Add songs again in this version so the native service can make its own persistent copies. Existing songs stored by the old WebView-only build do not automatically transfer into native storage.
- Assign songs to Rain, Cloudy, Sunny, Thunderstorm, Fog, Snow, or Default in the Weather → Sound panel.
- Keep notifications enabled; the persistent FEELING ABHISA notification indicates the foreground service is running.
- On Vivo/Android 11, set FEELING ABHISA battery use to **Unrestricted / allow background activity**. For restart recovery, grant **Allow all the time** location access in Android app settings if offered. If Android/Vivo blocks location access after reboot, reopen the app and grant the requested permissions.

## Honest platform limits
Android and Vivo can still stop background work when the user force-stops the app, revokes permissions, disables background activity, or applies aggressive battery restrictions. Weather is checked approximately every 15 minutes, so a weather change is detected on the next successful check, not instantaneously. Weather data needs internet and a usable device location. This project cannot promise uninterrupted playback under every OS/vendor condition.

## Technical notes
- Native song copies are stored privately under the app's internal files directory.
- Weather service uses Open-Meteo current weather data and Android's last-known location.
- Weather polling and playback use a foreground service with a persistent notification.
- Android boot receiver attempts to restart the service after reboot; Android's background-location and foreground-service rules still apply.
